document.addEventListener('DOMContentLoaded', () => {

    // --- Splash Screen Transition ---
    const splashScreen = document.getElementById('splash-screen');
    setTimeout(() => {
        if (splashScreen) splashScreen.classList.add('slide-up');
    }, 2800); // 2.8s display time

    // --- Authentication ---
    const authScreen = document.getElementById('auth-screen');
    const dashboardMain = document.getElementById('dashboard-main');
    const btnLogin = document.getElementById('btn-login');

    btnLogin.addEventListener('click', () => {
        // Simulate Auth
        authScreen.style.opacity = '0';
        setTimeout(() => {
            authScreen.classList.add('hidden');
            dashboardMain.classList.add('dashboard-active');
            initDashboard();
        }, 500);
    });

    // --- Core Dashboard Engine ---
    function initDashboard() {
        const map = L.map('map', { zoomControl: false }).setView([30.9009, 75.8572], 12); // Punjab
        L.control.zoom({ position: 'bottomright' }).addTo(map);

        L.tileLayer('https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}', {
            attribution: '&copy; Google Maps', maxZoom: 20
        }).addTo(map);

        setTimeout(() => document.getElementById('map').classList.add('map-loaded'), 200);

        // DOM Elements
        let selectedFarmId = null;
        const audioAlert = document.getElementById('alert-sound');
        const dom = {
            name: document.getElementById('selected-field-name'),
            moistVal: document.getElementById('val-moisture'),
            moistBar: document.getElementById('bar-moisture'),
            tempVal: document.getElementById('val-temp'),
            tempBar: document.getElementById('bar-temp'),
            humVal: document.getElementById('val-humidity'),
            humBar: document.getElementById('bar-humidity'),
            status: document.getElementById('val-status'),
            alertsContainer: document.getElementById('alerts-container'),
            alertBadge: document.getElementById('alert-count'),
            btnTrigger: document.getElementById('btn-trigger'),
            btnResolveAll: document.getElementById('btn-resolve-all')
        };

        const createMarkerIcon = (type) => {
            let className = 'map-marker';
            if (type === 'danger') className += ' marker-danger';
            if (type === 'warning') className += ' marker-warning';
            return L.divIcon({ className: 'custom-icon', html: `<div class="${className}"></div>`, iconSize: [24, 24], iconAnchor: [12, 12] });
        };

        const farms = [
            { id: 'Field Alpha', lat: 30.9200, lng: 75.8300, moist: 65, temp: 28.4, hum: 42, type: 'normal' },
            { id: 'Sector 4', lat: 30.8500, lng: 75.8000, moist: 70, temp: 27.0, hum: 40, type: 'normal' },
            { id: 'Zone Beta', lat: 30.8800, lng: 75.9000, moist: 72, temp: 26.5, hum: 38, type: 'normal' },
            { id: 'Field Gamma', lat: 30.9500, lng: 75.8800, moist: 60, temp: 27.8, hum: 45, type: 'normal' }
        ];

        farms.forEach(farm => {
            farm.marker = L.marker([farm.lat, farm.lng], { icon: createMarkerIcon(farm.type) }).addTo(map);
            farm.marker.on('click', () => {
                selectedFarmId = farm.id;
                updateFocusCard();
                map.flyTo([farm.lat, farm.lng], 13, { duration: 1.0 });
            });
        });

        L.circle([30.8800, 75.8500], { color: '#10b981', fillColor: '#10b981', fillOpacity: 0.05, weight: 1, radius: 8000 }).addTo(map);

        let activeAlerts = [];

        function updateFocusCard() {
            if (!selectedFarmId) return;
            const farm = farms.find(f => f.id === selectedFarmId);
            if (!farm) return;

            dom.name.innerText = `${farm.id} (Live Monitor)`;
            dom.moistVal.innerText = `${farm.moist.toFixed(1)}%`;
            dom.moistBar.style.width = `${farm.moist}%`;
            dom.moistBar.className = farm.moist < 35 ? 'fill danger' : (farm.moist < 50 ? 'fill warning' : 'fill');
            dom.tempVal.innerText = `${farm.temp.toFixed(1)}°C`;
            dom.tempBar.style.width = `${(farm.temp / 45) * 100}%`;
            dom.tempBar.className = farm.temp > 35 ? 'fill danger' : 'fill';
            dom.humVal.innerText = `${farm.hum.toFixed(1)}%`;
            dom.humBar.style.width = `${farm.hum}%`;

            if (farm.moist < 35) {
                dom.status.innerText = 'CRITICAL';
                dom.status.style.color = 'var(--danger-red)';
            } else {
                dom.status.innerText = 'Optimal';
                dom.status.style.color = 'var(--primary-green-dark)';
            }
        }

        function renderAlerts() {
            dom.alertBadge.innerText = `${activeAlerts.length} Alerts`;
            dom.alertBadge.className = activeAlerts.length > 0 ? 'badge badge-red' : 'badge badge-green';

            if (activeAlerts.length === 0) {
                dom.alertsContainer.innerHTML = '<p style="color: var(--text-muted); font-size: 0.875rem; text-align: center; margin: 20px 0;">Network Stable. No alerts detected.</p>';
                return;
            }

            dom.alertsContainer.innerHTML = activeAlerts.map(alert => `
              <div class="alert-item" id="alert-${alert.farmId.replace(' ', '-')}">
                <div class="alert-icon-wrapper red-bg">
                   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4m0 4h.01"/></svg>
                </div>
                <div class="alert-content">
                  <h4>${alert.title} - ${alert.farmId}</h4>
                  <p>${alert.message}</p>
                  <button class="action-btn-small primary" onclick="resolveIssue('${alert.farmId}')">Address Issue</button>
                </div>
              </div>
          `).join('');
        }

        window.resolveIssue = function (farmId) {
            const farm = farms.find(f => f.id === farmId);
            if (farm) {
                farm.moist = 75 + Math.random() * 10;
                farm.temp = 25 + Math.random() * 4;
                farm.type = 'normal';
                farm.marker.setIcon(createMarkerIcon('normal'));
            }
            activeAlerts = activeAlerts.filter(a => a.farmId !== farmId);
            renderAlerts();
            if (selectedFarmId === farmId) updateFocusCard();
        };

        function checkThresholds() {
            farms.forEach(farm => {
                if (farm.moist < 35) {
                    if (farm.type !== 'danger') {
                        farm.type = 'danger';
                        farm.marker.setIcon(createMarkerIcon('danger'));
                        if (!activeAlerts.find(a => a.farmId === farm.id)) {
                            activeAlerts.push({
                                farmId: farm.id, title: 'Critical Drought Deficit',
                                message: `Soil moisture plummeted to ${farm.moist.toFixed(1)}%. Immediate irrigation required.`
                            });
                            audioAlert.play().catch(e => console.log('Audio disabled'));
                            renderAlerts();
                        }
                    }
                } else if (farm.moist >= 35 && farm.type === 'danger') {
                    farm.type = 'normal';
                    farm.marker.setIcon(createMarkerIcon('normal'));
                    activeAlerts = activeAlerts.filter(a => a.farmId !== farm.id);
                    renderAlerts();
                }
            });
        }

        setInterval(() => {
            farms.forEach(farm => {
                farm.moist -= (Math.random() * 1.5 + 0.1);
                farm.temp += (Math.random() * 1.0 - 0.5);
                farm.hum += (Math.random() * 2.0 - 1.0);
                if (farm.moist < 0) farm.moist = 0;
            });
            checkThresholds();
            updateFocusCard();
        }, 3000);

        dom.btnTrigger.addEventListener('click', () => {
            const target = farms.find(f => f.id === 'Field Alpha');
            target.moist = 20.5; target.temp = 38.0;
            checkThresholds(); updateFocusCard();
        });

        dom.btnResolveAll.addEventListener('click', () => resolveAllSensors());

        function resolveAllSensors() {
            farms.forEach(farm => {
                farm.moist = 80 + Math.random() * 5;
                farm.temp = 24 + Math.random() * 2;
                farm.type = 'normal';
                farm.marker.setIcon(createMarkerIcon('normal'));
            });
            activeAlerts = [];
            renderAlerts();
            updateFocusCard();
        }

        // Export resolve for Chatbot usage
        window.triggerResolveAll = resolveAllSensors;

        // Top Navigation Connections
        const btnVoice = document.getElementById('btn-voice');
        const voiceLangNav = document.getElementById('voice-lang');
        const searchInput = document.querySelector('.search-bar input');

        if (btnVoice) {
            btnVoice.addEventListener('click', () => {
                document.getElementById('chat-window').classList.remove('hidden');
                document.getElementById('chat-lang').value = voiceLangNav.value;
                document.getElementById('chat-mic').click();
            });
        }
        
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const term = searchInput.value.toLowerCase();
                    const matched = farms.find(f => f.id.toLowerCase().includes(term));
                    if (matched) {
                        matched.marker.fire('click');
                    } else {
                        searchInput.value = "";
                        searchInput.placeholder = "Field not found...";
                        setTimeout(() => searchInput.placeholder = "Search fields, crops, or zones...", 2000);
                    }
                }
            });
        }
    }

    // --- AgriBot Multilingual Chatbot ---
    const chatFab = document.getElementById('chat-fab');
    const chatWindow = document.getElementById('chat-window');
    const closeChat = document.getElementById('close-chat');
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatMic = document.getElementById('chat-mic');
    const chatLang = document.getElementById('chat-lang');

    chatFab.addEventListener('click', () => chatWindow.classList.remove('hidden'));
    closeChat.addEventListener('click', () => chatWindow.classList.add('hidden'));

    // Sync Navigation Lang with Chat Lang globally
    const voiceLangNav = document.getElementById('voice-lang');
    if (voiceLangNav) {
        voiceLangNav.addEventListener('change', (e) => {
            chatLang.value = e.target.value;
        });
    }
    chatLang.addEventListener('change', (e) => {
        if (voiceLangNav) voiceLangNav.value = e.target.value;
    });

    function addMessage(text, sender) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `msg ${sender}`;
        // Convert simple markdown to HTML safely
        const formattedText = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>').replace(/\*(.*?)\*/g, '<i>$1</i>').replace(/\n/g, '<br>');
        msgDiv.innerHTML = formattedText;
        chatMessages.appendChild(msgDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function speakResponse(text, lang) {
        if ('speechSynthesis' in window) {
            // Clean markdown for speech
            const cleanText = text.replace(/[*#_]/g, '');
            const utterance = new SpeechSynthesisUtterance(cleanText);
            utterance.lang = lang;
            // slow down speech slightly for non-english languages for clarity
            utterance.rate = lang === 'en-IN' ? 1.0 : 0.9;
            
            // Explicitly force the voice engine to match the selected language
            const voices = window.speechSynthesis.getVoices();
            if (voices.length > 0) {
                const exactVoice = voices.find(v => v.lang === lang || v.lang.replace('_', '-') === lang);
                const partialVoice = voices.find(v => v.lang.startsWith(lang.split('-')[0]));
                if (exactVoice) utterance.voice = exactVoice;
                else if (partialVoice) utterance.voice = partialVoice;
            }
            
            window.speechSynthesis.speak(utterance);
        }
    }

    // Pre-load voices
    if ('speechSynthesis' in window) {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }

    // --- AI API Configuration ---
    const GEMINI_API_KEY = "AIzaSyB2q8bQI3BkHwqo58yhYEuCDUcL4AM-SnA"; // Replace with real Gemini API key for true automated solutions
    async function fetchAIResponse(problem, langCode) {
        if (GEMINI_API_KEY === "YOUR_API_KEY_HERE" || !GEMINI_API_KEY.startsWith("AIza")) {
            return null; // Fallback to mock dictionary if no key is provided
        }

        let modelName = "models/gemini-1.5-flash";
        let url = `https://generativelanguage.googleapis.com/v1beta/${modelName}:generateContent?key=${GEMINI_API_KEY}`;
        
        // Hard-map codes to explicit names to ensure the AI definitely outputs the correct dialect
        const languageMap = {
            'en-IN': 'English', 'hi-IN': 'Hindi', 'ta-IN': 'Tamil', 'te-IN': 'Telugu',
            'ml-IN': 'Malayalam', 'kn-IN': 'Kannada', 'pa-IN': 'Punjabi', 'mr-IN': 'Marathi'
        };
        const languageName = languageMap[langCode] || langCode;

        const prompt = `You are AgriBot, an expert agricultural AI assistant for a smart dashboard called AgriTrace X. 
      IMPORTANT: The user has selected the language: ${languageName}.
      Regardless of the language the farmer's question is written in, YOU MUST TRANSLATE YOUR THOUGHTS AND REPLY STRICTLY AND ONLY IN ${languageName}.
      Please provide a highly practical, 2-sentence solution to their farming problem in the native script of ${languageName}.
      Farmer's question: "${problem}"`;

        try {
          let res = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
          });
          let data = await res.json();
          
          // --- Auto-Discovery Model Correction ---
          if (data.error && data.error.message.includes("is not found")) {
              console.log("Model rejected by Google. Attempting auto-discovery of valid models...");
              const listRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`);
              const listData = await listRes.json();
              
              if (listData.models && listData.models.length > 0) {
                  // Find any model that their key allows which specifically supports generateContent
                  const validModel = listData.models.find(m => m.supportedGenerationMethods && m.supportedGenerationMethods.includes("generateContent"));
                  if (validModel) {
                      url = `https://generativelanguage.googleapis.com/v1beta/${validModel.name}:generateContent?key=${GEMINI_API_KEY}`;
                      res = await fetch(url, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
                      });
                      data = await res.json();
                  } else {
                      return `[API ERROR] Your API Key is valid, but your Google Cloud account is blocking generative models entirely. Please check billing or permissions on AI Studio.`;
                  }
              }
          }

          if (data.error) {
              console.error("Gemini API Error:", data.error.message);
              return `[API ERROR] ${data.error.message}`;
          }

          if (data.candidates && data.candidates[0].content.parts[0].text) {
              return data.candidates[0].content.parts[0].text;
          }
      } catch (e) {
          console.error("AI Fetch Connection Error:", e);
      }
      return null;
    }

    // Multilingual NLP Dictionary & True AI Integration
    async function processBotResponse(userInput) {
        const text = userInput.toLowerCase();
        const lang = chatLang.value;

        addMessage("Thinking...", 'bot'); // Typing indicator
        const typingIndicator = chatMessages.lastElementChild;

        let response = await fetchAIResponse(userInput, lang);

        // Hardware integration trigger (Smart resolution)
        const waterKeys = ['water', 'irrigate', 'paani', 'dry', 'sinchai', 'sukha', 'sookh', 'sinchan', 'pani', 'पाणी', 'fix', 'solve', 'theek'];
        if (waterKeys.some(k => text.includes(k))) {
            if (window.triggerResolveAll) window.triggerResolveAll(); // Programmatically water the sensors
        }

        if (!response) {
            // Fallback if no API key is provided
            const pestKeys = ['pest', 'kide', 'bug', 'keere', 'insects', 'kida', 'rog', 'alya', 'किडे', 'रोग'];
            const hasPests = pestKeys.some(k => text.includes(k));
            const needsWater = waterKeys.some(k => text.includes(k));

            if (hasPests) {
                if (lang === 'en-IN') response = "I detect a pest issue. I recommend spraying organic Neem oil today. Drone alert logged.";
                else if (lang === 'hi-IN') response = "Main samajh gaya ki kheton mein kide hain. Main organic neem oil spray karne ki salaah deta hoon.";
                else if (lang === 'pa-IN') response = "Main samajh gya ke khet vich keere han. Main organic neem oil di varton di salah dinda haan.";
                else if (lang === 'mr-IN') response = "Mala samajle ki shetat kide ahet. Me organic neem oil fawaranyacha salla deto.";
                else if (lang === 'ta-IN') response = "பூச்சிகள் உள்ளன. இன்று ஆர்கானிக் வேப்ப எண்ணெய் தெளிக்கவும்.";
                else if (lang === 'te-IN') response = "పురుగుల సమస్యను గుర్తించాను. వేప నూనెను వాడండి.";
                else if (lang === 'ml-IN') response = "കീട പ്രശ്നം കണ്ടെത്തുന്നു. വേപ്പെണ്ണ തളിക്കുക.";
                else if (lang === 'kn-IN') response = "ಕೀಟ ಸಮಸ್ಯೆಯನ್ನು ಪತ್ತೆಹಚ್ಚಲಾಗಿದೆ. ಬೇವಿನ ಎಣ್ಣೆಯನ್ನು ಬಳಸಿ.";
                else response = "I detect a pest issue. I recommend spraying organic Neem oil today.";
            }
            else if (needsWater) {
                if (lang === 'en-IN') response = "Detected water distress. I am now activating the smart irrigation pipeline.";
                else if (lang === 'hi-IN') response = "Kheton mein paani ki kami pakdi gayi hai. Main abhi sinchai pranali chalu kar raha hoon.";
                else if (lang === 'pa-IN') response = "Khet vich paani di ghaat mili hai. Main hun sinchai system chalu kar riha haan.";
                else if (lang === 'mr-IN') response = "Shetat panyachi kamtarata ahe. Me ata sinchan pranali chalu karat ahe.";
                else if (lang === 'ta-IN') response = "நீர் பற்றாக்குறை கண்டறியப்பட்டது. பாசன பைப்லைனை செயல்படுத்துகிறேன்.";
                else if (lang === 'te-IN') response = "నీటి కొరతను గుర్తించారు. నీటిపారుదల పైప్‌లైన్‌ను సక్రియం చేస్తున్నాను.";
                else if (lang === 'ml-IN') response = "വെള്ളത്തിൻ്റെ കുറവ് കണ്ടെത്തി. ഇറിഗേഷൻ പൈപ്പ്ലൈൻ സജീവമാക്കുന്നു.";
                else if (lang === 'kn-IN') response = "ನೀರಿನ ಕೊರತೆಯನ್ನು ಪತ್ತೆಹಚ್ಚಲಾಗಿದೆ. ನೀರಾವರಿ ಪೈಪ್‌ಲೈನ್ ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುತ್ತಿದ್ದೇನೆ.";
                else response = "Detected water distress. I am now activating the smart irrigation pipeline.";
            }
            else {
                if (lang === 'en-IN') response = "[No AI Key Detected] I am operating on static mode. Please insert a Gemini API key in script.js to unlock dynamic AI solutions.";
                else if (lang === 'hi-IN') response = "[AI Key Missing] Kripaya map/code mein API Key darj karein takii main dynamic uttar de sakun.";
                else if (lang === 'pa-IN') response = "[AI Key Missing] Kripa karke dynamic jawab layee code vich API Key pao.";
                else if (lang === 'mr-IN') response = "[AI Key Missing] Kharya AI kariyasathi krupaya API Key script.js madhye taka.";
                else if (lang === 'ta-IN') response = "[AI Key Missing] டைனமிக் AI திறக்க, script.js இல் API விசையைச் சேர்க்கவும்.";
                else if (lang === 'te-IN') response = "[AI Key Missing] డైనమిక్ AI అన్‌లాక్ చేయడానికి script.jsలో API కీని చేర్చండి.";
                else if (lang === 'ml-IN') response = "[AI Key Missing] ഡൈനാമിക് ഐ അൺലോക്ക് ചെയ്യാൻ സ്ക്രിപ്റ്റ്.js-ൽ API കീ ചേർക്കുക.";
                else if (lang === 'kn-IN') response = "[AI Key Missing] ಡೈನಾಮಿಕ್ ಎಐ ಅನ್ಲಾಕ್ ಮಾಡಲು ದಯವಿಟ್ಟು ಸ್ಕ್ರಿಪ್ಟ್.ಜೆಎಸ್ ನಲ್ಲಿ ಎಪಿಐ ಕೀಲಿಯನ್ನು ಸೇರಿಸಿ.";
                else response = "[No AI Key Detected] I am operating on static mode. Please insert a Gemini API key in script.js.";
            }
        }

        typingIndicator.innerText = response;
        speakResponse(response, lang);
    }

    chatSend.addEventListener('click', () => {
        const text = chatInput.value.trim();
        if (!text) return;
        addMessage(text, 'user');
        chatInput.value = '';
        processBotResponse(text);
    });

    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') chatSend.click();
    });

    // --- Chatbot Voice Recognition ---
    const voiceOverlay = document.getElementById('voice-overlay');
    const voiceLiveText = document.getElementById('voice-live-text');
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        
        let liveTranscript = '';
        let voiceHandled = false;

        const processVoiceFinish = () => {
            if (voiceHandled) return;
            voiceHandled = true;
            voiceOverlay.classList.add('hidden');
            
            if (liveTranscript && liveTranscript.trim().length > 0) {
                 addMessage(liveTranscript, 'user');
                 processBotResponse(liveTranscript);
            }
            liveTranscript = '';
        };

        chatMic.addEventListener('click', () => {
            liveTranscript = '';
            voiceHandled = false;
            recognition.lang = chatLang.value;
            
            // Explicitly unlock SpeechSynthesis audio engine for Mobile/Safari
            if ('speechSynthesis' in window) {
                let dummy = new SpeechSynthesisUtterance('');
                dummy.volume = 0;
                window.speechSynthesis.speak(dummy);
            }

            try { recognition.start(); } catch (e) {} // prevent double start errors
            voiceOverlay.classList.remove('hidden');
            voiceLiveText.innerText = "Listening...";
        });

        // Tap overlay to forcefully submit text immediately bridging any browser bugs
        voiceOverlay.addEventListener('click', () => {
            try { recognition.stop(); } catch(e) {}
            processVoiceFinish();
        });

        recognition.onresult = (event) => {
            let current = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                current += event.results[i][0].transcript;
            }
            liveTranscript = current;
            voiceLiveText.innerText = liveTranscript;
        };

        recognition.onerror = (e) => {
            if (e.error === 'no-speech' || e.error === 'aborted') {
                // Ignore standard early exits
            } else {
                voiceLiveText.innerText = `Mic Error: ${e.error}. Permissions allowed?`;
            }
            setTimeout(() => { if (!voiceHandled) processVoiceFinish(); }, 2500);
        };

        recognition.onend = () => {
             processVoiceFinish();
        };
    } else {
        chatMic.style.display = 'none';
    }

});
